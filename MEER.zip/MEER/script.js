document.getElementById('bookRideBtn').addEventListener('click', function() {
    const pickup = document.getElementById('pickup').value;
    const destination = document.getElementById('destination').value;

    if (!pickup || !destination) {
        alert('Please fill in both fields.');
        return;
    }

    alert(`Ride booked from ${pickup} to ${destination}!`);
});
let walletBalance = 0;

document.getElementById('addFundsBtn').addEventListener('click', function () {
    const amount = parseFloat(document.getElementById('addFunds').value);
    if (isNaN(amount) || amount <= 0) {
        alert('Enter a valid amount.');
        return;
    }
    walletBalance += amount;
    updateWalletBalance();
    alert(`Added $${amount.toFixed(2)} to your wallet.`);
});

document.getElementById('bookRideBtn').addEventListener('click', function () {
    const pickup = document.getElementById('pickup').value;
    const destination = document.getElementById('destination').value;
    const rideCost = 10; // Example ride cost

    if (!pickup || !destination) {
        alert('Please fill in both fields.');
        return;
    }

    if (walletBalance < rideCost) {
        alert('Insufficient wallet balance. Please add funds.');
        return;
    }

    walletBalance -= rideCost;
    updateWalletBalance();
    alert(`Ride booked from ${pickup} to ${destination}! $10 deducted.`);
});

function updateWalletBalance() {
    document.getElementById('walletBalance').textContent = `$${walletBalance.toFixed(2)}`;
}
